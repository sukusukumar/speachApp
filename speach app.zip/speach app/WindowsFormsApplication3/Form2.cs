﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using System.IO;

namespace WindowsFormsApplication3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SpeechSynthesizer ss, ss1;
        private void button1_Click(object sender, EventArgs e)
        {
            ss = new SpeechSynthesizer();
            try
            {

                ss.Speak(richTextBox1.Text.ToString());
            }
            catch (Exception ee)
            {
                MessageBox.Show("" + ee.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                ss1 = new SpeechSynthesizer();
                SaveFileDialog savefile = new SaveFileDialog();
                savefile.Filter = "All files (*.*)|*.*|wav files (*.wav)|*.wav";
                savefile.Title = "Save  file";
                savefile.FilterIndex = 2;
                savefile.RestoreDirectory = true;
                if (savefile.ShowDialog() == DialogResult.OK)
                {
                    FileStream files = new FileStream(savefile.FileName, FileMode.Create, FileAccess.Write);
                    ss1.SetOutputToWaveStream(files);
                    ss1.Speak(richTextBox1.Text);
                    files.Close();
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
        }
    }
}
