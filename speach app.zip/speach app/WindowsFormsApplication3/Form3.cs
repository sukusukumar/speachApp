﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.IO;

namespace WindowsFormsApplication3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        SpeechRecognitionEngine sre, sre1;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string s = comboBox1.Text.ToString();
                if (s == "Direct Voice")
                {
                    button1.Enabled = false;
                    label3.Visible = true;
                    sre = new SpeechRecognitionEngine();
                    sre.LoadGrammar(new DictationGrammar());
                    sre.SpeechRecognized += recognized_1;
                    sre.SetInputToDefaultAudioDevice();
                    sre.RecognizeAsync(RecognizeMode.Multiple);
                }
                else if (s == "Wave file (.wav)")
                {
                    button1.Enabled = false;
                    sre1 = new SpeechRecognitionEngine();
                    sre1.LoadGrammar(new DictationGrammar());
                    sre1.SpeechRecognized += recognized_2;
                    OpenFileDialog open = new OpenFileDialog();
                    open.Filter = "wav files (*.wav)|*.wav";
                    open.Title = "Open File";
                    open.FilterIndex = 1;
                    open.ShowDialog();
                    sre1.SetInputToWaveFile(open.FileName);
                    sre1.RecognizeAsync(RecognizeMode.Multiple);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
        }
        void recognized_1(object sender, SpeechRecognizedEventArgs e)
        {
            richTextBox1.Text += e.Result.Text.ToString();
            if (e.Result.Text == "stop")
            {
                sre.Dispose();
                button1.Enabled = true;
                label3.Visible = false;
            }
        }
        void recognized_2(object sender, SpeechRecognizedEventArgs e)
        {
            richTextBox1.Text += e.Result.Text.ToString();
            //if(e.Result==null)
            button1.Enabled = true;
            //sre1.Dispose();
        }
    }
}
